package org.aksw.jena_sparql_api.core;

import com.google.common.base.Function;

public interface TransformerQueryExecutionFactory
    extends Function<QueryExecutionFactory, QueryExecutionFactory>
{
}
