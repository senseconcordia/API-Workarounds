package org.aksw.jena_sparql_api.shape;

import com.google.common.base.Function;

public interface ResourceShapeParser
    extends Function<String, ResourceShape>
{

}
