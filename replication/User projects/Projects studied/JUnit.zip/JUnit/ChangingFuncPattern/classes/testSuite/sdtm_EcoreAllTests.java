/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.openhealthtools.mdht.uml.cda.sdtm.tests;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>sdtm_Ecore</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class sdtm_EcoreAllTests extends TestSuite {

	/**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public static void main(String[] args) {
    TestRunner.run(suite());
  }

	/**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public static Test suite() {
    TestSuite suite = new sdtm_EcoreAllTests("sdtm_Ecore Tests");
    suite.addTest(SdtmTests.suite());
    return suite;
  }

	/**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public sdtm_EcoreAllTests(String name) {
    super(name);
  }

} //sdtm_EcoreAllTests
