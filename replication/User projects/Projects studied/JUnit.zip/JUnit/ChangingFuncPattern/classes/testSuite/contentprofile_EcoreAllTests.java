/**
 */
package org.hl7.security.ds4p.contentprofile.tests;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>contentprofile_Ecore</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class contentprofile_EcoreAllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new contentprofile_EcoreAllTests("contentprofile_Ecore Tests");
		suite.addTest(CONTENTPROFILETests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public contentprofile_EcoreAllTests(String name) {
		super(name);
	}

} // contentprofile_EcoreAllTests
