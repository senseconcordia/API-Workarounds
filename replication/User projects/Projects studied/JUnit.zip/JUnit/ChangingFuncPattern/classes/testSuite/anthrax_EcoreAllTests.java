/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.openhealthtools.mdht.uml.cda.phcr.anthrax.tests;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>anthrax_Ecore</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class anthrax_EcoreAllTests extends TestSuite {

	/**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public static void main(String[] args) {
    TestRunner.run(suite());
  }

	/**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public static Test suite() {
    TestSuite suite = new anthrax_EcoreAllTests("anthrax_Ecore Tests");
    suite.addTest(AnthraxTests.suite());
    return suite;
  }

	/**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public anthrax_EcoreAllTests(String name) {
    super(name);
  }

} //anthrax_EcoreAllTests
