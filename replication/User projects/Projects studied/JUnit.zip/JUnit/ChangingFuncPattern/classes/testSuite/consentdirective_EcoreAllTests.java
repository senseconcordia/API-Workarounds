/**
 */
package org.hl7.cbcc.privacy.consentdirective.tests;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>consentdirective_Ecore</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class consentdirective_EcoreAllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new consentdirective_EcoreAllTests("consentdirective_Ecore Tests");
		suite.addTest(CONSENTDIRECTIVETests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public consentdirective_EcoreAllTests(String name) {
		super(name);
	}

} //consentdirective_EcoreAllTests
